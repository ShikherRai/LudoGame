import pygame
import random
import time

# Initialize Pygame
pygame.init()

# Screen settings
WIDTH, HEIGHT = 600, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Ludo Game")

# Load images
assets_path = "assets/"
board_img = pygame.image.load(assets_path + "ludo_board.png")
dice_imgs = [pygame.image.load(assets_path + f"dice_{i}.png") for i in range(1, 7)]
token_img = pygame.image.load(assets_path + "token.png")

# Resize images
board_img = pygame.transform.scale(board_img, (WIDTH, HEIGHT))
token_img = pygame.transform.scale(token_img, (40, 40))

# Colors
WHITE = (255, 255, 255)

# Player data
players = ["Player 1", "AI Player"]
player_positions = {"Player 1": [50, 50], "AI Player": [50, 100]}  # Start positions
turn = 0  # Player turn index
current_dice = 1
running = True
home_zones = {"Player 1": [500, 500], "AI Player": [500, 550]}  # Home positions

# Function to roll dice with animation
def roll_dice_animation():
    global current_dice
    for _ in range(10):
        current_dice = random.randint(1, 6)
        screen.fill(WHITE)
        screen.blit(board_img, (0, 0))
        screen.blit(dice_imgs[current_dice - 1], (250, 250))
        pygame.display.update()
        time.sleep(0.1)

# Function for AI move
def ai_move():
    global turn
    time.sleep(1)  # Simulate AI thinking
    roll_dice_animation()
    dice_value = current_dice
    player_positions["AI Player"][0] += dice_value * 40  # Move AI token
    if player_positions["AI Player"] == home_zones["AI Player"]:
        print("AI Player Wins!")
        pygame.quit()
    turn = (turn + 1) % len(players)  # Switch turn

# Main game loop
while running:
    screen.fill(WHITE)
    screen.blit(board_img, (0, 0))

    # Display the dice
    dice_x, dice_y = 250, 250
    screen.blit(dice_imgs[current_dice - 1], (dice_x, dice_y))

    # Draw player tokens
    for player, pos in player_positions.items():
        screen.blit(token_img, (pos[0], pos[1]))

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE and players[turn] == "Player 1":
                roll_dice_animation()
                dice_value = current_dice
                player_positions["Player 1"][0] += dice_value * 40
                if player_positions["Player 1"] == home_zones["Player 1"]:
                    print("Player 1 Wins!")
                    pygame.quit()
                turn = (turn + 1) % len(players)

    if players[turn] == "AI Player":
        ai_move()

    pygame.display.update()

pygame.quit()
